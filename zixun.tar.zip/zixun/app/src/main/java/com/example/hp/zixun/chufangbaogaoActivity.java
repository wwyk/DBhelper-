package com.example.hp.zixun;

import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by HP on 2018/10/26.
 */

public class chufangbaogaoActivity extends AppCompatActivity {
    private int id;
    private String data;
    private String datetime;
    private String title;

    private TextView tzgg_title;
    private TextView tzgg_datetime;
    private TextView tzgg_data;
}
